# ------------------------------------------------- #
# Title: Assignment05.py
# Dev:   John Humphreys
# Date:  10/28/2017
# Desc:  This program manages a To-Do list in ToDo.txt
# ChangeLog:  JHumphreys, 10/29/2017, Added more code>
# ------------------------------------------------- #

# -- Data -- #
# declare variables and constants
lstTable = []
strItem = ''
strPriority = ''

# -- Processing -- #
# open text file, read each row of data, write each row to individual dictionary, and
# write each dictionary to one master list
objFile = open('C:\\_PythonClass\\Mod5\\ToDo.txt', 'r')
for row in objFile:
    row = row.split(',')
    dic = {row[0]: row[1].rstrip('\n')}
    lstTable.append(dic)
objFile.close()

# -- Presentation (I/O) -- #
# get user input
# send program output
print('List contains:', lstTable)
while True:
    print('''
    Menu of Options
    1) Show current data.
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File.
    5) Exit Program.
    ''')
    strChoice = str(input('Which option would you like to perform? [1 to 4] - '))
    print()  # adding a new line

    # Show the current items in the table
    if strChoice.strip() == '1':
        print(lstTable)
        continue
    # Add a new item to the list/Table
    elif strChoice.strip() == '2':
        strItem = input('Enter a new item ')
        strPriority = input('Assign a priority [high, medium, or low] - ')
        dic = {strItem: strPriority}
        lstTable.append(dic)
        continue
    # Remove an item from the list/Table
    elif strChoice == '3':
        strItem = input('Enter name of item to be removed ')
        for dic in lstTable:
            if strItem in dic:
                lstTable.remove(dic)
                print(strItem + ' found and removed')
        continue
    # Save tasks to the ToDo.txt file
    elif strChoice == '4':
        objFile = open('C:\\_PythonClass\\Mod5\\ToDo.txt', 'w')
        for dic in lstTable:
            strDic = str(dic)
            strDic = strDic.replace('{', '')
            strDic = strDic.replace('}', '')
            strDic = strDic.replace('\'', '')
            strDic = strDic.replace(':', ',')
            strDic = strDic.replace(', ', ',')
            objFile.write(strDic + '\n')
        objFile.close()
        print('Data saved to ToDo.txt')
        continue
    elif strChoice == '5':
        break  # and Exit the program
